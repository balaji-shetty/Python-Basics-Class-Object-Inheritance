a=2
print(a)