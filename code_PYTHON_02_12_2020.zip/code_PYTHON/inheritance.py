import math

class Shape:
    def __init__(self, name):
        self.name = name

    def area(self):
        pass
        
    def getName(self):
        return self.name
        
class Rectangle(Shape):
    def __init__(self, name, length, breadth):
        super().__init__(name)
        self.length = length
        self.breadth = breadth
        
    def area(self):
        return self.length*self.breadth

class Square(Rectangle):
    def __init__(self, name, side):
        super().__init__(name,side,side)
        
class Circle(Shape):
    def __init__(self, name, radius):
        super().__init__(name)
        self.radius = radius

    def area(self):
        return 3.14*self.radius**2
	

s1 = Shape("John")

print("Area of Rectangle:")
r1 = Rectangle("RR",12,10)
ar1 = r1.area()
print(ar1)


print("Area of Square:")
s1 = Square("SS",15)
as1 = s1.area()
print(as1)


print("Area of Circle:")
c1 = Circle("SS",2)
ac1 = c1.area()
print(ac1)




	
		