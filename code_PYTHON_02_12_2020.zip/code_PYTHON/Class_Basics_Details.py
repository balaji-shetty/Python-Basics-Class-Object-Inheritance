class Person:
  def __init__(self, n, a):
    self.name = n
    self.amount = a

  def myfunc(self,age):
    print("Hello my name is " + self.name)
    print("Hello Age is ")
    print(age)
   
  def myamount(self):
    print(self.amount)  
  
  def show(self,dob,place):
    print("Name is " + self.name)  
    print("Amount is ")  
    print(self.amount)      
    print("date Of Birth is:"+ dob)      
    print("Place is:" + place)      
  
print("____________________________")
p1 = Person("John", 1000)

print("Name is---" + p1.name)
print("Amount is---" )
print(p1.amount)

p1.amount=9999
print("________After Calling myfunc()____________________")

p1.myfunc(21)
p1.myamount()

print("_________SHOW FuNction___________________")
p1.show("2 Dec 1980","LATUR")
print("_________SHOW FuNction___******________________")
