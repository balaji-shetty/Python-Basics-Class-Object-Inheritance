class Person:
  def __init__(self, n, a):
    self.name = n
    self.amount = a

  def myfunc(self):
    print("Hello my name is " + self.name)
   
  def myamount(self):
    print(self.amount)  
   
  def deposit(self, d):
    self.amount = self.amount + d
     
  def withdraw(self, w):
    self.amount = self.amount - w    

p1 = Person("John", 1000)
p1.myfunc()
p1.myamount()

print("_________Deposit 100________")
p1.deposit(100)

print("_________withdraw 50 _______")

p1.myamount()
print("____________________________")
p1.withdraw(50)
p1.myamount()