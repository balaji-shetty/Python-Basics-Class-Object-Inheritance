class Person:
  def __init__(self, n, a):
    self.name = n
    self.amount = a

  def myfunc(self):
    print("Hello my name is " + self.name)
   
  def myamount(self):
    print(self.amount)  
  
  def show(self):
    print("Name is " +self.name)  
    print("Amount is ")  
    print(self.amount)      
  
print("____________________________")
p1 = Person("John", 1000)
print("Name is---" + p1.name)
print("Amount is---" )
print(p1.amount)
p1.amount=9999

print("________After Calling myfunc()____________________")
p1.myfunc()
p1.myamount()
print("_________SHOW FuNction___________________")
p1.show()
print("_________SHOW FuNction___******________________")
