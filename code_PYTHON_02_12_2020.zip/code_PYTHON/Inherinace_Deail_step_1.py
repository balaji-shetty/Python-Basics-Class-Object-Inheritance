class Person:
  def __init__(self, fname, lname):
    self.firstname = fname
    self.lastname = lname

  def printname(self):
    print(self.firstname, self.lastname)

class Student(Person):
  def __init__(self, fname, lname,loc):
    Person.__init__(self, fname, lname)
    self.location = loc
    
  def print_location(self):
    print("Inside function -Location is " + self.location)   

x = Student("Mike", "Olsen","LATUR")
x.printname()

print("First Name is " + x.firstname)
print("Last Name is " + x.lastname)
print("Location is " + x.location)

x.print_location()

